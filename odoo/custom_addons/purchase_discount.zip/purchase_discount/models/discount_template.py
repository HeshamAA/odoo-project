from odoo import fields, models


class PurchaseDiscount(models.Model):
    _name = 'purchase.discount'
    _description = 'Purchase Discount'
    _order = 'name'

    name = fields.Char(required=True)
    discount_value = fields.Float('Percentage (%)', required=True, digits='Discount')

    def name_get(self):
        result = []
        for rec in self:
            result.append((rec.id, f"{rec.name} ({rec.discount_value}%)"))
        return result
