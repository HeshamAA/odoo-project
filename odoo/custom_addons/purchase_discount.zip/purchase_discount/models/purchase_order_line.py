from odoo import api, fields, models


class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'

    discount_ids = fields.Many2many(
        'purchase.discount',
        'purchase_order_line_discount_rel',
        'line_id',
        'discount_id',
        string='Discounts',
        context={'active_test': True},
    )

    price_unit_before_discount = fields.Float(
        string='Unit Price',
        digits='Product Price',
        store=True,
        copy=True,
        default=0.0,
    )

    price_unit = fields.Float(
        string='Unit Price',
        digits='Product Price',
        compute='_compute_price_unit_and_date_planned_and_name',
        store=True,
        readonly=False,
    )

    @api.depends(
        'price_unit_before_discount',
        'discount_ids.discount_value',
        'product_qty',
    )
    def _compute_price_unit_and_date_planned_and_name(self):
        super()._compute_price_unit_and_date_planned_and_name()

        for line in self:
            if not line.product_id:
                continue

            if line.technical_price_unit and line.technical_price_unit == line.price_unit:
                line.price_unit_before_discount = line.price_unit

            base = line.price_unit_before_discount
            if not base:
                continue

            if not line.discount_ids:
                line.price_unit = base
                continue

            qty = line.product_qty or 1.0
            total = base * qty
            for disc in line.discount_ids:
                total *= (1.0 - disc.discount_value / 100.0)
            line.discount = 0.0
            line.price_unit = max(total, 0.0) / qty

    @api.onchange('price_unit_before_discount')
    def _onchange_price_unit_before_discount(self):
        for line in self:
            if not line.discount_ids:
                line.price_unit = line.price_unit_before_discount
